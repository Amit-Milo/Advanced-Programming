//
// Created by yoav on 21/12/2019.
//

#ifndef EX3_INTERPRETERFILES_INTERPRETERINCLUDES_H_
#define EX3_INTERPRETERFILES_INTERPRETERINCLUDES_H_

#include "CalculationTokensCreatorChecker.h"
#include "TokensToExpressionConverter.h"
#include "Interpreter.h"

#endif //EX3_INTERPRETERFILES_INTERPRETERINCLUDES_H_
