//
// Created by yoav on 22/12/2019.
//

#include "VarCommand.h"
#include "../Containers/Container.h"

VarCommand::VarCommand(Container *container) : Command(container) {}

